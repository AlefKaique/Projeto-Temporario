<?php

    $dbHost = 'Localhost';
    $dbUsername = 'root';
    $dbPasssword = '';
    $dbName = 'users';

    $conexao = new mysqli($dbHost,$dbUsername,$dbPasssword,$dbName);

?>